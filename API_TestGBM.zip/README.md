API_TestGBM

Author: Victor Esuebio Olvera Thome

Test project for simulate sales and purchases of stocks. 

For enviroment need set a connection string to database, first in DataAccess only for migration
and next in appsettings in main project for use.