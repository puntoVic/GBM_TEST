﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Responses
{
    public class Business_Error
    {
        public string Error { get; set; }
    }
}
